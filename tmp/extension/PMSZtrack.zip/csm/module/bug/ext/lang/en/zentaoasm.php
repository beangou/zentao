<?php
$lang->bug->createFromZenTaoASM = 'Create bug from zentaoASM';
