<?php
$lang->bug->createFromZenTaoASM = '从ZenTaoASM创建';
