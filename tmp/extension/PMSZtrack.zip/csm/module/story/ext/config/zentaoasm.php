<?php
$config->story->editor->createfromzentaoasm = array('id' => 'spec,verify', 'tools' => 'simpleTools');
