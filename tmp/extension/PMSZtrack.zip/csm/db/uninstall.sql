ALTER TABLE `zt_user` DROP `isSync`;
