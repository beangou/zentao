<?php
$paramDefaultValue['bug']['createfromzentaoasm']['extras'] = '';
$paramDefaultValue['bug']['createfromzentaoasm']['requestID'] = 0;
$paramDefaultValue['feedback']['browse']['type'] = 'transfered';
$paramDefaultValue['feedback']['browse']['param'] = '';
$paramDefaultValue['feedback']['browse']['orderBy'] = 'id_asc';
$paramDefaultValue['feedback']['browse']['recTotal'] = '0';
$paramDefaultValue['feedback']['browse']['recPerPage'] = '20';
$paramDefaultValue['feedback']['browse']['pageID'] = '1';
$paramDefaultValue['feedback']['view']['viewType'] = 'view';
$paramDefaultValue['story']['createfromzentaoasm']['productID'] = 0;
$paramDefaultValue['story']['createfromzentaoasm']['moduleID'] = 0;
$paramDefaultValue['story']['createfromzentaoasm']['storyID'] = 0;
$paramDefaultValue['story']['createfromzentaoasm']['requestID'] = 0;
