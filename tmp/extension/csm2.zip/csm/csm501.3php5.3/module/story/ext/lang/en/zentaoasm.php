<?php
$lang->story->createFromZenTaoASM = 'Create story from zentaoASM';
