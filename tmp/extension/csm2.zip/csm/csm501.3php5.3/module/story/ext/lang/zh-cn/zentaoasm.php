<?php
$lang->story->createFromZenTaoASM = '从ZenTaoASM创建';
