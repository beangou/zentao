<?php 
$config->feedback->api->root = '';
$config->feedback->api->key  = '';
