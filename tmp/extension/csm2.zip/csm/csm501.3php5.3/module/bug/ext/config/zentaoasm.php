<?php
$config->bug->editor->createfromzentaoasm = array('id' => 'steps', 'tools' => 'bugTools');
