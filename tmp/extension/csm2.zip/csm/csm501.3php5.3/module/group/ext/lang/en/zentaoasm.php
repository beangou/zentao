<?php
$lang->resource->feedback->index       = 'index';
$lang->resource->feedback->browse      = 'browse';
$lang->resource->feedback->view        = 'view';
$lang->resource->feedback->reply       = 'reply';
$lang->resource->feedback->toBug       = 'toBug';
$lang->resource->feedback->toStory     = 'toStory';
$lang->resource->feedback->setConfig   = 'setConfig';
$lang->resource->feedback->syncProduct = 'syncProduct';
$lang->resource->feedback->syncUser    = 'syncUser';

$lang->resource->bug->createFromZenTaoASM   = 'createFromZenTaoASM';
$lang->resource->story->createFromZenTaoASM = 'createFromZenTaoASM';
