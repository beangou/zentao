<?php
$lang->menu->feedback = '反馈|feedback|index';
$lang->feedback->menu->browse       = array('link' => '问题列表|feedback|browse', 'alias' => 'view');
$lang->feedback->menu->syncProduct  = '同步产品|feedback|syncproduct';
$lang->feedback->menu->syncUser     = '同步用户|feedback|syncuser';
$lang->feedback->menu->setConfig    = '设置配置|feedback|setconfig';

$lang->bug->menu->bug['alias'] .= ',createfromzentaoasm';

$lang->sync   = '同步';
$lang->source = '来源:';
