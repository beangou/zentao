<?php
$lang->menu->feedback = 'Feedback|feedback|index';
$lang->feedback->menu->browse       = array('link' => 'Request|feedback|browse', 'alias' => 'view');
$lang->feedback->menu->syncProduct  = 'Sync Product|feedback|syncproduct';
$lang->feedback->menu->syncUser     = 'Sync User|feedback|syncuser';
$lang->feedback->menu->setConfig    = 'Setting|feedback|setconfig';

$lang->bug->menu->bug['alias'] .= ',createfromzentaoasm';

$lang->sync   = 'Sync';
$lang->source = 'Source:';
